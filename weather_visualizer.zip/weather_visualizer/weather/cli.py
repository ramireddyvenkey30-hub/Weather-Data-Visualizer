"""Menu-driven terminal interface."""
import os

from . import analytics, export, plotting, storage
from .models import WeatherRecord
from .validation import (ValidationError, parse_city, parse_condition, parse_date,
                         parse_humidity, parse_rain, parse_temp)

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_FILE = os.path.join(BASE, "data", "weather_data.json")
SEED_CSV = os.path.join(BASE, "data", "sample_weather.csv")
OUT_DIR = os.path.join(BASE, "output")

C = {"b": "\033[1m", "g": "\033[92m", "y": "\033[93m", "r": "\033[91m", "c": "\033[96m", "0": "\033[0m"}
PAGE = 15


def paint(text, color):
    return text if os.environ.get("NO_COLOR") else f"{C[color]}{text}{C['0']}"


BANNER = r"""
 __        __         _   _
 \ \      / /__  __ _| |_| |__   ___ _ __
  \ \ /\ / / _ \/ _` | __| '_ \ / _ \ '__|
   \ V  V /  __/ (_| | |_| | | |  __/ |
    \_/\_/ \___|\__,_|\__|_| |_|\___|_|
        D A T A   V I S U A L I Z E R
"""

MENU = """
  1. View records          5. Plot charts
  2. Add a record          6. Export reports
  3. Search / filter       7. Bulk import CSV
  4. Summary & trends      8. Threshold warnings
  9. Delete a record       0. Exit
"""


def ask(prompt, parser, default=None):
    """Loop until the parser accepts the input (never crashes on bad input)."""
    while True:
        try:
            raw = input(f"  {prompt}" + (f" [{default}]" if default is not None else "") + ": ")
        except EOFError:
            raise SystemExit(0)
        if raw.strip() == "" and default is not None:
            raw = str(default)
        try:
            return parser(raw)
        except ValidationError as e:
            print(paint(f"  x {e}", "r"))


def table(records):
    if not records:
        print(paint("  No matching records.", "y"))
        return
    head = f"  {'#':>3} {'Date':<11}{'City':<16}{'Temp C':>7}{'Rain mm':>9}{'Hum %':>7}  Condition"
    for start in range(0, len(records), PAGE):
        print(paint(head, "b")); print("  " + "-" * (len(head) - 2))
        for i, r in enumerate(records[start:start + PAGE], start + 1):
            print(f"  {i:>3} {r.date:<11}{r.city[:15]:<16}{r.temp_c:>7.1f}{r.rainfall_mm:>9.1f}{r.humidity:>7.0f}  {r.condition}")
        if start + PAGE < len(records):
            if input(f"  -- {start + PAGE}/{len(records)} shown, Enter for more, q to stop: ").lower() == "q":
                break
    print(f"  ({len(records)} record(s))")


def add_record(records):
    print(paint("\n  Add record (dates as YYYY-MM-DD)", "c"))
    date = ask("Date", parse_date)
    city = ask("City", parse_city)
    if any(r.key == (date, city.lower()) for r in records):
        print(paint("  x A record for that date and city already exists.", "r"))
        return
    rec = WeatherRecord(
        date, city,
        ask("Temperature C (-90..60)", parse_temp),
        ask("Rainfall mm (0..2000)", parse_rain),
        ask("Humidity % (0..100)", parse_humidity),
        ask("Condition (optional)", parse_condition, default=""),
    )
    records.append(rec)
    storage.save_records(DATA_FILE, records)
    print(paint("  ✓ Saved.", "g"))
    for w in analytics.warnings([rec]):
        print(paint(f"  ! {w}", "y"))


def search_menu(records):
    print(paint("\n  Search (leave blank to skip a filter)", "c"))
    kw = input("  Keyword (city/condition/date): ")
    city = input("  Exact city: ")
    start = input("  From date (YYYY-MM-DD): ").strip()
    end = input("  To date (YYYY-MM-DD): ").strip()
    try:
        start = parse_date(start) if start else ""
        end = parse_date(end) if end else ""
    except ValidationError as e:
        print(paint(f"  x {e}", "r")); return
    table(analytics.search(records, kw, city, start, end))


def show_summary(records):
    s = analytics.summarize(records)
    if not s:
        print(paint("  No data yet.", "y")); return
    print(paint("\n  ===== EXECUTIVE SUMMARY =====", "b"))
    for line in export.summary_lines(s):
        print("  " + line)
    print(paint("\n  Monthly", "c"))
    for m, d in s["monthly"].items():
        print(f"   {m}  avg {d['avg_temp']:>6} C   rain {d['total_rain']:>8} mm   ({d['n']} days)")
    print(paint("\n  By city", "c"))
    for c, d in s["by_city"].items():
        print(f"   {c:<15} avg {d['avg_temp']:>6} C   rain {d['total_rain']:>8} mm   ({d['n']} days)")
    print(paint(f"\n  {len(s['warnings'])} warning(s) - see option 8.", "y" if s["warnings"] else "g"))


def plot_menu(records):
    city = input("  City to plot (blank = all): ").strip()
    try:
        for p in plotting.plot_all(records, OUT_DIR, city):
            print(paint(f"  ✓ Saved {os.path.relpath(p, BASE)}", "g"))
    except RuntimeError as e:
        print(paint(f"  x {e}", "r"))


def import_menu(records):
    path = input("  Path to CSV file: ").strip().strip('"')
    good, errors = storage.import_csv(path, records)
    records.extend(good)
    storage.save_records(DATA_FILE, records)
    print(paint(f"  ✓ Imported {len(good)} row(s); {len(errors)} rejected.", "g" if not errors else "y"))
    if errors:
        log = os.path.join(OUT_DIR, "import_errors.log")
        storage.write_error_log(log, errors)
        for e in errors[:10]:
            print(f"    - {e}")
        if len(errors) > 10:
            print(f"    ... and {len(errors) - 10} more")
        print(f"  Full log: {os.path.relpath(log, BASE)}")


def delete_menu(records):
    shown = sorted(records, key=lambda r: (r.date, r.city))
    table(shown)
    if not shown:
        return
    raw = input("  Number to delete (blank to cancel): ").strip()
    if not raw.isdigit() or not 1 <= int(raw) <= len(shown):
        print("  Cancelled."); return
    records.remove(shown[int(raw) - 1])
    storage.save_records(DATA_FILE, records)
    print(paint("  ✓ Deleted.", "g"))


def main():
    print(paint(BANNER, "c"))
    records = storage.load_records(DATA_FILE, SEED_CSV)
    print(f"  Loaded {len(records)} record(s) from {os.path.relpath(DATA_FILE, BASE)}")
    while True:
        print(MENU)
        choice = input("  Choose an option: ").strip()
        if choice == "1":
            table(sorted(records, key=lambda r: (r.date, r.city)))
        elif choice == "2":
            add_record(records)
        elif choice == "3":
            search_menu(records)
        elif choice == "4":
            show_summary(records)
        elif choice == "5":
            plot_menu(records)
        elif choice == "6":
            s = analytics.summarize(records)
            if not s:
                print(paint("  No data to export.", "y"))
            else:
                for p in export.export_reports(s, records, OUT_DIR):
                    print(paint(f"  ✓ Saved {os.path.relpath(p, BASE)}", "g"))
        elif choice == "7":
            import_menu(records)
        elif choice == "8":
            w = analytics.warnings(records)
            print("\n".join(paint("  ! " + x, "y") for x in w) if w else paint("  No warnings.", "g"))
        elif choice == "9":
            delete_menu(records)
        elif choice == "0":
            print("  Goodbye!"); return
        else:
            print(paint("  x Please enter a number from the menu.", "r"))
