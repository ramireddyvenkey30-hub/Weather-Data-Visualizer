"""Weather Data Visualizer - a beginner-friendly terminal app."""
__version__ = "1.0.0"
