"""Export summary reports as Markdown, plain-text audit log, and CSV."""
import csv
import os
from datetime import datetime

from .storage import FIELDS


def summary_lines(s):
    return [
        f"Records analysed : {s['count']}",
        f"Cities           : {', '.join(s['cities'])}",
        f"Date range       : {s['date_range'][0]} to {s['date_range'][1]}",
        f"Avg temperature  : {s['avg_temp']} C  (trend: {s['trend']})",
        f"Hottest day      : {s['hottest'].date} {s['hottest'].city} {s['max_temp']} C",
        f"Coldest day      : {s['coldest'].date} {s['coldest'].city} {s['min_temp']} C",
        f"Total rainfall   : {s['total_rain']} mm over {s['rainy_days']} rainy days",
        f"Wettest day      : {s['wettest'].date} {s['wettest'].city} {s['wettest'].rainfall_mm} mm",
        f"Avg humidity     : {s['avg_humidity']} %",
    ]


def export_reports(summary, records, out_dir="output"):
    os.makedirs(out_dir, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    paths = []

    md = os.path.join(out_dir, f"summary_{stamp}.md")
    with open(md, "w", encoding="utf-8") as f:
        f.write("# Weather Summary Report\n\n")
        f.write(f"_Generated {datetime.now():%Y-%m-%d %H:%M}_\n\n## Key Metrics\n\n")
        for line in summary_lines(summary):
            k, v = line.split(":", 1)
            f.write(f"- **{k.strip()}**: {v.strip()}\n")
        f.write("\n## Monthly Breakdown\n\n| Month | Avg Temp (C) | Rain (mm) | Days |\n|---|---|---|---|\n")
        for m, d in summary["monthly"].items():
            f.write(f"| {m} | {d['avg_temp']} | {d['total_rain']} | {d['n']} |\n")
        f.write("\n## Warnings\n\n")
        f.write("\n".join(f"- {w}" for w in summary["warnings"]) or "None")
        f.write("\n")
    paths.append(md)

    txt = os.path.join(out_dir, f"audit_{stamp}.txt")
    with open(txt, "w", encoding="utf-8") as f:
        f.write(f"AUDIT LOG {datetime.now():%Y-%m-%d %H:%M:%S}\n" + "=" * 50 + "\n")
        f.write("\n".join(summary_lines(summary)) + "\n\nWARNINGS\n")
        f.write("\n".join(summary["warnings"]) or "None")
        f.write("\n")
    paths.append(txt)

    csv_path = os.path.join(out_dir, f"records_{stamp}.csv")
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        for r in sorted(records, key=lambda r: (r.date, r.city)):
            w.writerow(r.to_dict())
    paths.append(csv_path)
    return paths
