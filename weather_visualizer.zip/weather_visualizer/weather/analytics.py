"""Summary statistics, search and threshold warnings."""
from collections import defaultdict
from statistics import mean

from .models import WeatherRecord

HEAT_C = 40.0
FREEZE_C = 0.0
HEAVY_RAIN_MM = 100.0


def search(records, keyword="", city="", start="", end=""):
    kw = keyword.lower().strip()
    out = []
    for r in records:
        if city.strip() and r.city.lower() != city.lower().strip():
            continue
        if start and r.date < start:
            continue
        if end and r.date > end:
            continue
        if kw and kw not in f"{r.city} {r.condition} {r.date}".lower():
            continue
        out.append(r)
    return sorted(out, key=lambda r: (r.date, r.city))


def warnings(records):
    flags = []
    for r in sorted(records, key=lambda r: r.date):
        if r.temp_c >= HEAT_C:
            flags.append(f"HEAT      {r.date} {r.city}: {r.temp_c:g} C (>= {HEAT_C:g})")
        if r.temp_c <= FREEZE_C:
            flags.append(f"FREEZE    {r.date} {r.city}: {r.temp_c:g} C (<= {FREEZE_C:g})")
        if r.rainfall_mm >= HEAVY_RAIN_MM:
            flags.append(f"HEAVYRAIN {r.date} {r.city}: {r.rainfall_mm:g} mm (>= {HEAVY_RAIN_MM:g})")
    return flags


def summarize(records: list[WeatherRecord]) -> dict | None:
    if not records:
        return None
    temps = [r.temp_c for r in records]
    rain = [r.rainfall_mm for r in records]
    hum = [r.humidity for r in records]
    monthly = defaultdict(list)
    by_city = defaultdict(list)
    for r in records:
        monthly[r.date[:7]].append(r)
        by_city[r.city].append(r)
    hottest = max(records, key=lambda r: r.temp_c)
    coldest = min(records, key=lambda r: r.temp_c)
    wettest = max(records, key=lambda r: r.rainfall_mm)
    ordered = sorted(records, key=lambda r: r.date)
    half = len(ordered) // 2
    trend = "n/a"
    if half >= 1:
        diff = mean(r.temp_c for r in ordered[half:]) - mean(r.temp_c for r in ordered[:half])
        trend = "warming" if diff > 0.5 else "cooling" if diff < -0.5 else "stable"
    return {
        "count": len(records),
        "cities": sorted(by_city),
        "date_range": (ordered[0].date, ordered[-1].date),
        "avg_temp": round(mean(temps), 2),
        "min_temp": coldest.temp_c, "coldest": coldest,
        "max_temp": hottest.temp_c, "hottest": hottest,
        "total_rain": round(sum(rain), 2),
        "avg_rain": round(mean(rain), 2),
        "wettest": wettest,
        "rainy_days": sum(1 for x in rain if x > 0),
        "avg_humidity": round(mean(hum), 2),
        "trend": trend,
        "monthly": {m: {"avg_temp": round(mean(x.temp_c for x in rs), 2),
                        "total_rain": round(sum(x.rainfall_mm for x in rs), 2),
                        "n": len(rs)} for m, rs in sorted(monthly.items())},
        "by_city": {c: {"avg_temp": round(mean(x.temp_c for x in rs), 2),
                        "total_rain": round(sum(x.rainfall_mm for x in rs), 2),
                        "n": len(rs)} for c, rs in sorted(by_city.items())},
        "warnings": warnings(records),
    }
