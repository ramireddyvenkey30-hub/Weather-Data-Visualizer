"""Matplotlib charts. Degrades gracefully if matplotlib is not installed."""
import os
from collections import defaultdict
from datetime import datetime


def _plt():
    try:
        import matplotlib
        matplotlib.use("Agg")  # headless-safe: saves PNGs, no window needed
        import matplotlib.pyplot as plt
        return plt
    except ImportError:
        return None


def plot_all(records, out_dir="output", city=""):
    """Create temperature trend, rainfall bars and temperature histogram. Returns file paths."""
    plt = _plt()
    if plt is None:
        raise RuntimeError("matplotlib is not installed. Run: pip install matplotlib")
    data = [r for r in records if not city or r.city.lower() == city.lower()]
    if not data:
        raise RuntimeError("No records to plot.")
    os.makedirs(out_dir, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    suffix = f"_{city.lower().replace(' ', '_')}" if city else ""
    paths = []

    by_city = defaultdict(list)
    for r in sorted(data, key=lambda r: r.date):
        by_city[r.city].append(r)

    fig, ax = plt.subplots(figsize=(10, 5))
    for c, rs in by_city.items():
        ax.plot([datetime.strptime(r.date, "%Y-%m-%d") for r in rs],
                [r.temp_c for r in rs], marker="o", label=c)
    ax.set(title="Temperature Trend", xlabel="Date", ylabel="Temperature (C)")
    ax.grid(alpha=0.3); ax.legend(); fig.autofmt_xdate()
    p = os.path.join(out_dir, f"temperature_trend{suffix}_{stamp}.png")
    fig.savefig(p, dpi=120, bbox_inches="tight"); plt.close(fig); paths.append(p)

    monthly = defaultdict(float)
    for r in sorted(data, key=lambda r: r.date):
        monthly[r.date[:7]] += r.rainfall_mm
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.bar(list(monthly), list(monthly.values()), color="#3b82f6")
    ax.set(title="Total Rainfall per Month", xlabel="Month", ylabel="Rainfall (mm)")
    ax.grid(axis="y", alpha=0.3); plt.setp(ax.get_xticklabels(), rotation=45)
    p = os.path.join(out_dir, f"rainfall_monthly{suffix}_{stamp}.png")
    fig.savefig(p, dpi=120, bbox_inches="tight"); plt.close(fig); paths.append(p)

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.hist([r.temp_c for r in data], bins=10, color="#f97316", edgecolor="white")
    ax.set(title="Temperature Distribution", xlabel="Temperature (C)", ylabel="Days")
    p = os.path.join(out_dir, f"temperature_distribution{suffix}_{stamp}.png")
    fig.savefig(p, dpi=120, bbox_inches="tight"); plt.close(fig); paths.append(p)
    return paths
