import os, sys, tempfile, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from weather import analytics, storage, validation as v

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SAMPLE = os.path.join(BASE, "data", "sample_weather.csv")
MESSY = os.path.join(BASE, "data", "messy_import_demo.csv")


class Tests(unittest.TestCase):
    def test_validation(self):
        self.assertEqual(v.parse_temp("25.456"), 25.46)
        for bad in ["", "abc", "99", "nan", "inf"]:
            with self.assertRaises(v.ValidationError):
                v.parse_temp(bad)
        with self.assertRaises(v.ValidationError): v.parse_humidity("101")
        with self.assertRaises(v.ValidationError): v.parse_rain("-1")
        with self.assertRaises(v.ValidationError): v.parse_date("2025-02-30")
        with self.assertRaises(v.ValidationError): v.parse_date("2999-01-01")
        self.assertEqual(v.parse_city("new delhi"), "New Delhi")

    def test_import_and_summary(self):
        recs, errs = storage.import_csv(SAMPLE)
        self.assertGreaterEqual(len(recs), 30); self.assertEqual(errs, [])
        s = analytics.summarize(recs)
        self.assertEqual(s["max_temp"], 48.5)
        self.assertTrue(any("HEAT" in w for w in s["warnings"]))

    def test_messy_import(self):
        recs, errs = storage.import_csv(MESSY)
        self.assertEqual(len(recs), 2); self.assertEqual(len(errs), 6)

    def test_persistence_and_corruption(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "x.json")
            recs, _ = storage.import_csv(SAMPLE)
            storage.save_records(p, recs)
            self.assertEqual(len(storage.load_records(p)), len(recs))
            open(p, "w").write("{not json")
            self.assertEqual(storage.load_records(p), [])

    def test_missing_file_seeds(self):
        with tempfile.TemporaryDirectory() as d:
            r = storage.load_records(os.path.join(d, "n.json"), SAMPLE)
            self.assertGreaterEqual(len(r), 30)

    def test_search(self):
        recs, _ = storage.import_csv(SAMPLE)
        res = analytics.search(recs, city="mumbai")
        self.assertTrue(res and all(r.city == "Mumbai" for r in res))


if __name__ == "__main__":
    unittest.main()
