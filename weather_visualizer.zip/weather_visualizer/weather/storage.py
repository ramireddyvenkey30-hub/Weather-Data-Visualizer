"""JSON persistence plus CSV import with row-by-row error logs."""
import csv
import json
import os
import shutil
from datetime import datetime

from .models import WeatherRecord
from .validation import ValidationError, validate_row

FIELDS = ["date", "city", "temp_c", "rainfall_mm", "humidity", "condition"]


def load_records(path: str, seed_csv: str | None = None) -> list[WeatherRecord]:
    """Load records. Missing file -> seed/empty; corrupt file -> back up and reset."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            raw = json.load(f)
        if not isinstance(raw, list):
            raise ValueError("Top-level JSON must be a list")
        return [WeatherRecord.from_dict(r) for r in raw]
    except FileNotFoundError:
        records = []
        if seed_csv and os.path.exists(seed_csv):
            records, _ = import_csv(seed_csv)
        save_records(path, records)
        return records
    except (json.JSONDecodeError, ValueError, KeyError, TypeError):
        backup = f"{path}.corrupt-{datetime.now():%Y%m%d%H%M%S}"
        shutil.copy(path, backup)
        print(f"  [!] Data file was corrupted. Backed up to {backup}; starting clean.")
        save_records(path, [])
        return []


def save_records(path: str, records: list[WeatherRecord]) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump([r.to_dict() for r in records], f, indent=2)
    os.replace(tmp, path)  # atomic: never leaves half-written file


def import_csv(path: str, existing: list[WeatherRecord] | None = None):
    """Return (valid_records, error_log). Skips duplicates and bad rows."""
    seen = {r.key for r in (existing or [])}
    good, errors = [], []
    try:
        with open(path, newline="", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            missing = [c for c in FIELDS[:5] if c not in (reader.fieldnames or [])]
            if missing:
                return [], [f"File header is missing columns: {', '.join(missing)}"]
            for line_no, row in enumerate(reader, start=2):
                try:
                    rec = validate_row(row)
                    if rec.key in seen:
                        raise ValidationError("Duplicate date/city entry.")
                    seen.add(rec.key)
                    good.append(rec)
                except ValidationError as e:
                    errors.append(f"Row {line_no}: {e}")
    except FileNotFoundError:
        return [], [f"File not found: {path}"]
    except (OSError, UnicodeDecodeError, csv.Error) as e:
        return [], [f"Could not read file: {e}"]
    return good, errors


def write_error_log(path: str, errors: list[str]) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(errors) + "\n")
