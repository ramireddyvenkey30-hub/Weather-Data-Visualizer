"""Defensive input validation - every function raises ValidationError, never crashes."""
import re
from datetime import datetime

from .models import WeatherRecord

TEMP_RANGE = (-90.0, 60.0)
RAIN_RANGE = (0.0, 2000.0)
HUMIDITY_RANGE = (0.0, 100.0)
CITY_RE = re.compile(r"^[A-Za-z][A-Za-z .'\-]{1,39}$")


class ValidationError(ValueError):
    pass


def parse_date(text: str) -> str:
    text = (text or "").strip()
    try:
        d = datetime.strptime(text, "%Y-%m-%d")
    except ValueError:
        raise ValidationError("Date must be a real date in YYYY-MM-DD format.")
    if d > datetime.now():
        raise ValidationError("Date cannot be in the future.")
    return text


def parse_city(text: str) -> str:
    text = (text or "").strip()
    if not CITY_RE.match(text):
        raise ValidationError("City must be 2-40 letters (spaces, . ' - allowed).")
    return text.title()


def parse_number(text, label: str, lo: float, hi: float) -> float:
    text = str(text if text is not None else "").strip()
    if text == "":
        raise ValidationError(f"{label} cannot be blank.")
    try:
        value = float(text)
    except ValueError:
        raise ValidationError(f"{label} must be a number.")
    if value != value or value in (float("inf"), float("-inf")):
        raise ValidationError(f"{label} must be a finite number.")
    if not lo <= value <= hi:
        raise ValidationError(f"{label} must be between {lo:g} and {hi:g}.")
    return round(value, 2)


def parse_temp(t):
    return parse_number(t, "Temperature (C)", *TEMP_RANGE)


def parse_rain(t):
    return parse_number(t, "Rainfall (mm)", *RAIN_RANGE)


def parse_humidity(t):
    return parse_number(t, "Humidity (%)", *HUMIDITY_RANGE)


def parse_condition(text: str) -> str:
    text = (text or "").strip()
    if len(text) > 30:
        raise ValidationError("Condition must be 30 characters or fewer.")
    return text.title()


def validate_row(row: dict) -> WeatherRecord:
    """Validate a raw dict (e.g. a CSV row) and return a clean record."""
    try:
        return WeatherRecord(
            date=parse_date(row.get("date")),
            city=parse_city(row.get("city")),
            temp_c=parse_temp(row.get("temp_c")),
            rainfall_mm=parse_rain(row.get("rainfall_mm")),
            humidity=parse_humidity(row.get("humidity")),
            condition=parse_condition(row.get("condition", "")),
        )
    except AttributeError:
        raise ValidationError("Malformed row.")
