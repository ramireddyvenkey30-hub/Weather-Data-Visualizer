from dataclasses import dataclass, asdict


@dataclass
class WeatherRecord:
    date: str          # YYYY-MM-DD
    city: str
    temp_c: float      # degrees Celsius
    rainfall_mm: float
    humidity: float    # percent
    condition: str = ""

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "WeatherRecord":
        return cls(
            date=d["date"], city=d["city"], temp_c=float(d["temp_c"]),
            rainfall_mm=float(d["rainfall_mm"]), humidity=float(d["humidity"]),
            condition=d.get("condition", "") or "",
        )

    @property
    def key(self):
        return (self.date, self.city.lower())
